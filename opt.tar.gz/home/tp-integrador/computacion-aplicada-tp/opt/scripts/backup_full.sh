#!/bin/bash

# Uso con opcion -h
if [ "1" = "-h" ]; then
  echo "Uso: backup_full.sh <direcotrio_origen>"
fi

# Directorios
ORIGEN=$1
DESTINO="/backup_dir"

if [ ! -d "$ORIGEN" ]; then
  echo "El directorio $ORIGEN no existe"
fi

if [ ! -d "$DESTINO" ]; then
  echo "El directorio $DESTINO no existe"
fi

FECHA=$(date +%Y%m%d)
BACKUP_NAME=$(basename $ORIGEN)_bkp_$FECHA.tar.gz

tar -czf $DESTINO/$BACKUP_NAME --absolute-names $ORIGEN
